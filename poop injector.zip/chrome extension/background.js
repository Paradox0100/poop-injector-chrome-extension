document.getElementById("APjFqb").value = 'poop';
const logo = document.querySelector(".jfN4p");
logo.src = "https://neural-networking.w3spaces.com/poop.png";
logo.style.height = "75px";
document.getElementById("result-stats").innerHTML = 'About 100,000,000,000 poops in (.01 seconds)';
